/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.ac.cput.assignment3project;

import java.io.BufferedWriter;
import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.time.LocalDate;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Locale;

/**
 *
 * @author Zaakirah Fakier 220461503
 */
public class ReadFile {
     String stakeholderFile = "stakeholder.ser";
    FileWriter fileW;
    BufferedWriter buffW;
    InputStream inputS;
    ObjectInputStream objectS;
public void openTheFile(String Files){
    
    try
    {
        fileW = new FileWriter(new File(Files));
        buffW = new BufferedWriter(fileW);
        System.out.println(" Has been created "+ Files );
    } 
    catch (IOException ioe)
    {
        System.exit(0);
    
    }
}
private ArrayList<Customer> customersArrList()
{
    ArrayList<Customer> customers = new ArrayList<>();
    try{
        inputS = new FileInputStream(stakeholderFile);
        objectS = new ObjectInputStream(inputS);
    while (true){
        Object kfc = objectS .readObject();
        if (kfc instanceof Customer){
            
        customers.add((Customer) kfc);
    }
  }
}  
    catch (EOFException eofe){
        
    } 
    catch (IOException | ClassNotFoundException e){
        
    System.exit(0);
    } 
    finally{
        
    try{
        buffW.close();
        objectS.close();
    } 
    catch (IOException e){
        
    }
  }
    if (!customers.isEmpty()){
        
        Collections.sort(customers,
        (Customer sort, Customer sorted) ->
         sort.getStHolderId().compareTo(sorted.getStHolderId())
       );
     }
        return customers;
}
public void customerShowOutput(){
        
    String formula = "%s\t%-10s\t%-10s\t%-10s\t%-10s\n";
    String line = 
    "===========================================================\n";
    try{ 
        
        System.out.print( "======================= CUSTOMERS =========================\n");
        System.out.printf(formula, "ID", "Name", "Surname",
        "Date Of Birth", "Age");
        System.out.print(line);
            for (int i = 0; i < customersArrList().size(); i++){ 
    
                System.out.printf(formula,customersArrList().get(i).getStHolderId(),customersArrList().get(i).getFirstName(),customersArrList().get(i).getSurName(),formDate(customersArrList().get(i).getDateOfBirth()),calculateTheAge(customersArrList().get(i).getDateOfBirth()));
                    }
                System.out.println("\nNumber of customers who can rent:" + cRent());
                System.out.println("Number of customers who cannot rent:"+ cNotRent());
                } 
    catch (Exception e){
        
        }
  }
private String formDate(String time){
    
    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd MMM yyyy",Locale.ENGLISH);LocalDate parTome = LocalDate.parse(time);
    return parTome.format(formatter);
    }
private int calculateTheAge(String time){
    
    LocalDate parseDob = LocalDate.parse(time);
    int dobYear = parseDob.getYear();
    ZonedDateTime todayDate = ZonedDateTime.now();
    int currentYear = todayDate.getYear();
    return currentYear - dobYear;
}
private int cRent(){
    int cRent = 0;
    for (int i = 0; i < customersArrList().size(); i++){
        if (customersArrList().get(i).getCanRent()){
        cRent += 1;
    
    }
 }
    return cRent;
    }
private int cNotRent(){
    
    int cNotRent = 0;
        for (int i = 0; i < customersArrList().size(); i++)
{
        if (!customersArrList().get(i).getCanRent())
        {
            cNotRent += 1;
     }
  }
        return cNotRent;
}
    private ArrayList<Supplier> supplierArrList()
    {
    ArrayList<Supplier> suppliers = new ArrayList<>();try
    {
        inputS = new FileInputStream(new File(stakeholderFile));
        objectS = new ObjectInputStream(inputS);
        while (true)
        {
        Object kfc = objectS.readObject();
        if (kfc instanceof Supplier)
        {
        suppliers.add((Supplier) kfc);
        }
        }
        } catch (EOFException eofe)
        {
        } catch (IOException | ClassNotFoundException e)
        {
        } finally{
        
        try{
        
            inputS.close();
            objectS.close();
        } 
        catch (IOException e){
        
        }
      }
        if (!suppliers.isEmpty()){
            
        Collections.sort(
        suppliers,
        (Supplier sup, Supplier lier) ->
        sup.getName().compareTo(lier.getName())
        );
     }
         return suppliers;
  }
public void supplierOutput(){
    try{
        
    System.out.print("======================= SUPPLIERS =============================\n");
    System.out.printf("%s\t%-20s\t%-10s\t%-10s\n", "ID", "Name", "Prod Type","Description");
    System.out.print("===============================================================\n");
    
    for (int i = 0; i < supplierArrList().size(); i++){
        
    System.out.printf("%s\t%-20s\t%-10s\t%-10s\n",supplierArrList().get(i).getStHolderId(),supplierArrList().get(i).getName(),supplierArrList().get(i).getProductType(),supplierArrList().get(i).getProductDescription());
        }
    } 
    catch (Exception e){
        
    }
 }
public void closeTheFile(String Files){
        try{
            
            fileW.close();
            buffW.close();
        System.out.println(Files + " has been closed");
        } 
        catch (IOException ex){
         }
    }
     
 public static void main(String[] args)
    {
        ReadFile send = new ReadFile();
        
        send.openTheFile("customerOutFile.txt");
        send.customerShowOutput();
        send.closeTheFile("customerOutFile.txt");
        System.out.println("---------------------------------------------------");
        send.openTheFile("supplierOutFile.txt");
        send.supplierOutput();
        send.closeTheFile("supplierOutFile.txt");
    }
}


